## experimental, this file isn't currently used at all
script_name	=	"/api/v1/"
errorlog	=  	'/var/log/gunicorn/error_log_yourapp'
